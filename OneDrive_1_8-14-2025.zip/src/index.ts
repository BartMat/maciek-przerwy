document.addEventListener('DOMContentLoaded', () => {
	const greeting = document.getElementById('greeting');
	if (greeting) {
		greeting.textContent = 'Hello, World!';
	}
});
